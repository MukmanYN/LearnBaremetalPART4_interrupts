/*
 * gpio.c
 *
 *  Created on: Dec 18, 2025
 *      Author: mukht
 */

#include "gpio.h"

#define GPIOAEN (1U<<0)

#define GPIOCEN (1U<<2)

void gpio_init(){

	RCC_AHB1ENR |= GPIOAEN;

	RCC_AHB1ENR |= GPIOCEN;
	// set to output
	GPIOA_MODER &= ~(1u<<11);
	GPIOA_MODER |= (1u<<10);

	// pin 13 set to input
	GPIOC_MODER &= ~(1u<<27);
	GPIOC_MODER &= ~(1u<<26);


	// pin 3 pull up
	GPIOA_PUPDR &= ~(1U<<7);
	GPIOA_PUPDR |= (1U<<6);

	//pin 2 pull up
	GPIOA_PUPDR &= ~(1U<<5);
	GPIOA_PUPDR |= (1U<<4);

	// pin 13 pull up
	GPIOC_PUPDR &= ~(1u<<27);
	GPIOC_PUPDR |= (1u<<26);

	 // pin2 set to AF7
	GPIOA_AFRL &= ~(1U<< 11);
	GPIOA_AFRL |= (1U<< 10);
	GPIOA_AFRL |= (1U<< 9);
	GPIOA_AFRL |= (1U<< 8);

	//pin 3 set to AF7
	GPIOA_AFRL &= ~(1U<< 15);
	GPIOA_AFRL |= (1U<< 14);
	GPIOA_AFRL |= (1U<< 13);
	GPIOA_AFRL |= (1U<< 12);

	// pin 2 alternate pin for USART2 TX
	GPIOA_MODER |= (1U<<5);
	GPIOA_MODER &= ~(1U<<4);

	// pin 3 alternate pin for USART2 RX
	GPIOA_MODER |= (1U<<7);
	GPIOA_MODER &= ~(1U<<6);

}


void gpio_ld2_on(){
	GPIOA_ODR |=  (1U<<5);  // GPIOA5
}


void gpio_ld2_off(){
	GPIOA_ODR &=  ~(1U<<5);  // GPIOA5
}

void gpio_ld2_toggle(){
	GPIOA_ODR ^=  (1U<<5);  // GPIOA5

}




