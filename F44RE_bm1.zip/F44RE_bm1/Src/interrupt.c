/*
 * interrupt.c
 *
 *  Created on: Dec 21, 2025
 *      Author: mukslinuxmachine
 */
#include "interrupt.h"




void interrupt_init(void){


	 // Enable SYSCFG clock (APB2)
	    RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN;

	    // Map EXTI13 to PC13: EXTICR4 bits [7:4] = 0b0010 (Port C)
	    SYSCFG->EXTICR[3] &= ~(0xFU << 4);
	    SYSCFG->EXTICR[3] |=  (0x2U << 4);

	    // Unmask EXTI13 interrupt
	    EXTI->IMR |= (1U << 13);

	    // Falling edge trigger, disable rising
	    EXTI->RTSR &= ~(1U << 13);
	    EXTI->FTSR |=  (1U << 13);

	    // Clear any stale pending flag BEFORE enabling NVIC
	    EXTI->PR = (1U << 13);   // write-1-to-clear

	    __disable_irq();
	    NVIC_ClearPendingIRQ(EXTI15_10_IRQn);
	    NVIC_SetPriority(EXTI15_10_IRQn, 3);
	    NVIC_EnableIRQ(EXTI15_10_IRQn);
	    __enable_irq();
}

