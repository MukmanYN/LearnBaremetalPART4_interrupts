

#include "usart.h"


void usart2_init(void){

	RCC_APB1ENR	|= USART2EN; // enable clock access USART2


	// set alternate functions in gpio.c pin 2 and pin3
	// set AF register to pin3 and pin2

	USART_CR1	&= ~(1U<<15); // OVERSAMPLE 16

	USART_CR1	&= ~(1U<<12); // Word length 8 bit

	// enable tx and rx functions
	USART_CR1	|= (1U<<3); // Transmit enable

	USART_CR1	|= (1U<<2); // Recieve enable

	USART_CR1	&= ~(1U<<10); // even parity

	USART_CR2	&= ~(1U<<13);	// 1 stop bit
	USART_CR2	&= ~(1U<<12);

	USART_CR1 |= RXNEIE;
	USART_BRR = ((16000000 + (115200/2U))/115200);		// 115200 buad

	USART_CR1	|= (1U<<13); // UART enable


}



void usart2_transmit_one_byte( int ch){
	// first we make sure data register isn't empty
		while(!(USART_SR & ISR_TXE)) // when we sure the data aint empty,
			;						//it evaluates to 1, then is notted 0 so while loop doenst run


		USART_DR = (ch & 0xFF);

}


void usart2_transmit(uint8_t * data,int len){
	// first we make sure data register isn't empty
	while(!(USART_SR & ISR_TXE)) // when we sure the data aint empty, it evaluates to 1, then is notted 0 so while loop doenst run
		;

	for(int i = 0; i < len; i++){
		USART_DR = data[i];
		while(!(USART_SR & ISR_TXE)) // when we sure the data aint empty, it evaluates to 1, then is notted 0 so while loop doenst run
				;
	}
}


void usart2_recieve_one_byte(uint8_t  * data){
	while(!(USART_SR & ISR_RXNE))  //make sure data aint empty
		;
	 *data = USART_DR;
}

int i = 0;
void	usart2_recieve(uint8_t * data){
	while(!(USART_SR & ISR_RXNE))  //make sure data aint empty
			;

	data[i] = USART_DR;
	i++;

	if( i == 10){
		i = 0;

	}

}

void usart2_set_baud(uint32_t peripheral_clock, uint32_t baudrate){

	USART_BRR = ((peripheral_clock + baudrate/2U)/ baudrate);

}
