/*
 * interrupt.h
 *
 *  Created on: Dec 21, 2025
 *      Author: mukslinuxmachine
 */

#ifndef INTERRUPT_H_
#define INTERRUPT_H_
#include "base.h"

#define RCC_APB2ENR_OFFSET  0x44
#define RCC_APB2ENR			(*(volatile unsigned int *)(APB2_PERIPHERAL + RCC_APB2ENR_OFFSET))

#define SYSCFG_EXTICR4_OFFSET  0x14
#define SYSCFG_EXTICR4		(*(volatile unsigned int *)(SYSCFG_PERIPHERAL + SYSCFG_EXTICR4_OFFSET))


#define EXTI_IMR_OFFSET 0x00
#define EXTI_IMR		(*(volatile unsigned int *)(EXTI_PERIPHERAL + EXTI_IMR_OFFSET))

#define EXTI_RTSR_OFFSET 0x08
#define EXTI_RTSR		(*(volatile unsigned int *)(EXTI_PERIPHERAL + EXTI_RTSR_OFFSET))

#define EXTI_FTSR_OFFSET 0x0C
#define EXTI_FTSR		(*(volatile unsigned int *)(EXTI_PERIPHERAL + EXTI_FTSR_OFFSET))

#define SYSCFGEN (1U<<14)

#define EXTI_PR_OFFSET	0x14
#define EXTI_PR			(*(volatile unsigned int *)(EXTI_PERIPHERAL + EXTI_PR_OFFSET))
void interrupt_init(void);

#endif /* INTERRUPT_H_ */
