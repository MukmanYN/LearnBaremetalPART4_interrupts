/*
 * usart.h
 *
 *  Created on: Dec 20, 2025
 *      Author: mukslinuxmachine
 */

#ifndef USART_H_
#define USART_H_
#include "base.h"
#include <stdint.h>

#define RCC_APB1ENR_OFFSET	0x40
#define RCC_APB1ENR		(*(volatile unsigned int *)(RCC_PERIPHERAL + RCC_APB1ENR_OFFSET))


#define USART_CR1_OFFSET 0x0C
#define USART_CR1		(*(volatile unsigned int *)(USART2_PERIPHERAL + USART_CR1_OFFSET))

#define USART_BRR_OFFSET	0x08
#define USART_BRR		(*(volatile unsigned int *)(USART2_PERIPHERAL + USART_BRR_OFFSET))


#define USART_DR_OFFSET 0x04
#define USART_DR		(*(volatile unsigned int *)(USART2_PERIPHERAL + USART_DR_OFFSET))


#define USART_SR_OFFSET	0x00
#define USART_SR	(*(volatile unsigned int *)(USART2_PERIPHERAL + USART_SR_OFFSET))


#define USART_CR2_OFFSET 0x10
#define USART_CR2	(*(volatile unsigned int *)(USART2_PERIPHERAL + USART_CR2_OFFSET))

#define USART2EN	(1U<<17)
#define ISR_TXE		(1U<<7)
#define ISR_RXNE	(1U<<5)
#define RXNEIE		(1U<<5)

void usart2_init(void);
void usart2_transmit_one_byte( int ch);
void usart2_transmit(uint8_t *data,int len);
void	usart2_recieve_one_byte(uint8_t * data);
void	usart2_recieve(uint8_t * data);
void usart2_set_baud(uint32_t peripheral_clock, uint32_t baudrate);
#endif /* USART_H_ */
