/*
 * gpio.h
 *
 *  Created on: Dec 18, 2025
 *      Author: mukht
 */
#include "base.h"
#ifndef GPIO_H_
#define GPIO_H_


#define GPIOA_MODER_OFFSET	 0x00
#define GPIOA_MODER			(*(volatile unsigned int *)(AHB1_PERIPHERAL + GPIOA_MODER_OFFSET))


#define GPIOA_ODR_OFFSET	 0x14
#define GPIOA_ODR 		(*(volatile unsigned int *)(AHB1_PERIPHERAL + GPIOA_ODR_OFFSET))


#define GPIOC_MODER_OFFSET		(0x00)
#define GPIOC_MODER			(*(volatile unsigned int *)(GPIOC_PERIPHERAL + GPIOC_MODER_OFFSET)) // means  goto this register address and r/w

#define GPIOC_IDR_OFFSET 0x10
#define GPIOC_IDR		(*(volatile unsigned int *)(GPIOC_PERIPHERAL + GPIOC_IDR_OFFSET)) // means  goto this register address and r/w

#define GPIOA_AFRL_OFFSET 0x20
#define GPIOA_AFRL  (*(volatile unsigned int *)(AHB1_PERIPHERAL + GPIOA_AFRL_OFFSET))

#define GPIOC_PUPDR_OFFSET 0x0C
#define GPIOC_PUPDR	(*(volatile unsigned int *)(AHB1_PERIPHERAL + GPIOA_PUPDR_OFFSET))


#define GPIOA_PUPDR_OFFSET 0x0C
#define GPIOA_PUPDR	(*(volatile unsigned int *)(AHB1_PERIPHERAL + GPIOA_PUPDR_OFFSET))

#define RCC_AHB1ENR_OFFSET	0x30
#define RCC_AHB1ENR		(*(volatile unsigned int *)(RCC_PERIPHERAL + RCC_AHB1ENR_OFFSET))


void gpio_init();
void gpio_ld2_on();
void gpio_ld2_off();

void gpio_ld2_toggle();
#endif /* GPIO_H_ */
